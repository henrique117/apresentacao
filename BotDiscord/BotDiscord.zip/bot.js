const Discord = require('discord.js');
const fs = require('fs');
    
const { Client, Intents } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });

var macaco = null

client.on('ready', () => {
    console.log('Rique Jr. está online!')
})

/* COMANDOS */

client.on('messageCreate', (message) => {
    if(message.content === '!comandos'){
        message.reply('!avatar, !davi, !daviado, !bart, !macaco, !higao')
    }
})

/* MACACO */

client.on('messageCreate', (message) => {
    if(message.content === '!macaco'){
        message.reply('Quantos macacos você quer?')
        var arrombado = message.author.id
        macaco = true
        client.on('messageCreate', (message) => {
            if(macaco === true){
                if(message.author.id === arrombado){
                    var nmacacos = parseInt(message.content)
                    if(Number.isInteger(nmacacos)){
                        if(nmacacos > 10){
                            message.reply('É muito macaco pra mim')
                            macaco = false
                            return
                        }else{
                            for(i = 0; i < nmacacos; i++){
                                message.channel.send('https://cdn.discordapp.com/emojis/857349489198497792.png?v=1')
                            }
                            message.reply('Receba seus macacos')
                            macaco = false
                            return
                        }
                    }else{
                        return
                    }
                }
            }else{
                return
            }
        })
    }else{
        return
    }
})

/* CARGO POR REAÇÃO */

/* client.on ("messageReactionAdd", (reaction_orig, message, user) => {
    if(message.id !== "876101655031083038") {
        return
    }else{
        let servidor = client.guilds.get("876101363443073034")
        let membro = servidor.members.get(reaction_orig.author.id)
        console.log(reaction_orig.author.id)
        console.log(reaction_orig._emoji.name)

        let cargo1 = servidor.roles.get('876102584476241931'),
            cargo2 = servidor.roles.get('876102649752211496'),
            cargo3 = servidor.roles.get('876102705070874634')

        if(reaction_orig._emoji.name === '❤️'){
            membro.addRole(cargo1)
        }else if(reaction_orig._emoji.id === '876101655031083038'){
            membro.addRole(cargo2)
        }else if(reaction_orig._emoji.id === '876101655031083038'){
            membro.addRole(cargo3)
        }else{
            return
        }
    }
}) */

/* client.on ("messageCreate", (message) => {
    let servidor = (message.guildId)
    let membro = (message.author.id)
    console.log(servidor)
    console.log(membro)
    console.log(servidor.roles)

    let cargo1 = servidor.roles.get('876102584476241931'),
        cargo2 = servidor.roles.get('876102649752211496'),
        cargo3 = servidor.roles.get('876102705070874634')

        if(message.content === '1'){
            membro.addRole(cargo1)
        }else if(message.content === '2'){
            membro.addRole(cargo2)
        }else if(message.content === '3'){
            membro.addRole(cargo3)
        }else{
            return
        }
}) */

/* MOSTRAR O AVATAR */

client.on("messageCreate", (message) => {
    if(message.content.startsWith('!avatar')){
        var foto = (message.content)
        if(foto.endsWith('!avatar')){
            var membro = message.mentions.members.first() || message.member;
            message.reply(message.author.displayAvatarURL({ dynamic: true, size: 4096 }));
        }else{
            var membro = message.mentions.members.first() || message.member;
            message.reply(membro.user.displayAvatarURL({ dynamic: true, size: 4096 }));  
        }
    }else{
        return
    }
})

/* PARABENS DAVI!!! */

client.on('messageCreate', (message) => {
    if (message.content === '!davi'){
        message.channel.send('Parabéns Davi!!! :partying_face: :partying_face: :partying_face:')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('https://cdn.discordapp.com/attachments/606596875835015196/877901765654220840/imagem_2021-08-19_100646_auto_x2.png')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('Parabéns pra você\nNesta data querida\nMuitas felicidades\nMuitos anos de vida!')
    }else{
        return
    }
})

/* PARABENS DAVIADO!!! */

client.on('messageCreate', (message) => {
    if (message.content === '!daviado'){
        message.channel.send('Parabéns Davi!!! :partying_face: :partying_face: :partying_face:')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877924956086874132/EbOLIgwWsAAcfFE.png')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('Parabéns pra você\nNesta data querida\nMuitas felicidades\nMuitos anos de vida!')
    }else{
        return
    }
})

/* PARABENS BART!!! */

client.on('messageCreate', (message) => {
    if (message.content === '!bart'){
        message.channel.send('Parabéns Barteleguinha!!! :partying_face: :partying_face: :partying_face:')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877905154651877416/66297639_1308918185938462_2154397935461203968_n.png')
        message.channel.send('https://tenor.com/view/balloon-gif-8189968')
        message.channel.send('Parabéns pra você\nNesta data querida\nMuitas felicidades\nMuitos anos de vida!')
    }else{
        return
    }
})

/* BOTA PRA CANTAR PAPUM */

client.on('messageCreate', (message) => {
    if(message.content === 'bota o fuzil pra cantar'){
        message.reply(':exploding_head: PA :boom: PUM :gun:')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877927013065842709/show.gif')
    }else if(message.content === 'bota o fuzil pra canta'){
        message.reply(':exploding_head: PA :boom: PUM :gun:')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877927013065842709/show.gif')
    }else if(message.content === 'Bota o fuzil pra canta'){
        message.reply(':exploding_head: PA :boom: PUM :gun:')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877927013065842709/show.gif')
    }else if(message.content === 'bota o fuzil pra cantar'){
        message.reply(':exploding_head: PA :boom: PUM :gun:')
        message.channel.send('https://cdn.discordapp.com/attachments/570036128753647642/877927013065842709/show.gif')
    }else{
        return
    }
})

/* AYAYAYA */

client.on('messageCreate', (message) => {
    var ayaka = message.content.indexOf('ayaka') > -1 || message.content.indexOf('Ayaka') > -1
    if(ayaka === true){
        message.reply('AYAYAYA')
    }
})

/* HIGAO */

client.on('messageCreate', (message) => {
    if(message.content === '!higao'){
        message.reply('https://uploads.twitchalerts.com/000/483/240/492/higao%20maior.PNG')
    }else{
        return
    }
})







/* LOGIN */

client.login('ODc1NzU5NTM2MTMxMTQ1NzM4.YRaMoA._f57HEHKDviNsJ6_QlM0lHHh3vc')